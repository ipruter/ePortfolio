from datetime import datetime

class Appointment:

    def __init__(self, app_ID, app_date, app_description): # Appointment constructor
        if app_ID == None or len(str(app_ID)) > 10: # Checks ID is not null or less than ten characters
            raise Exception("ID can't be greater than ten characters.")

        if app_date == None: # Checks date is not null
            raise Exception("Date required.")

        if app_description == None or len(str(app_description)) > 50: # Checks description is not null or less than fifty characters
            raise Exception("Appointment can't be greater than fifty characters.")

        # Strips whitespace from strings
        temp_appointment_ID = app_ID.strip()
        temp_appointment_description = app_description.strip()

        if temp_appointment_ID == "": # Checks that ID is not empty
            raise Exception("ID can't be empty.")

        if temp_appointment_description == "": # Checks that date is not empty
            raise Exception("Description can't be empty.")

        current = datetime.today()

        if app_date < current: # Checks that date is not in the past
            raise Exception("Time can not be in the past.")

        # Assigns new attributes to the object
        self.appointment_ID = app_ID
        self.appointment_date = app_date
        self.appointment_description = app_description



