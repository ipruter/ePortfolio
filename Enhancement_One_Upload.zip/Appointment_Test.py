from Appointment import Appointment
from Appointment_Service import Appointment_Service
from datetime import datetime
from unittest import TestCase

class Appointment_Test(TestCase):

    def test_appointment(self): # Tests constructor
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        app_obj = Appointment("1", appointment_date, "Two cleaners for 9:00 AM") # Initializes Appointment object
        # Compares new object against expected output
        self.assertTrue(app_obj.appointment_ID == "1")
        self.assertTrue(app_obj.appointment_date == appointment_date)
        self.assertTrue(app_obj.appointment_description == "Two cleaners for 9:00 AM")

    def test_appointmentID_too_long(self): # Test ID length exception
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        with self.assertRaises(Exception): # Checks if exception is thrown from a long ID
            Appointment("11111111111111111111111111111", appointment_date, "Two cleaners for 9:00 AM")

    def test_appointmentID_null(self): # Test appointment ID is null exception
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        with self.assertRaises(Exception): # Checks if exception is thrown from a null ID
            Appointment(None, appointment_date, "Two cleaners for 9:00 AM")

    def test_appointment_date_null(self): # Test appointment ID is null exception
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        with self.assertRaises(Exception): # Checks if exception is thrown from a null date
            Appointment("1", None, "Two cleaners for 9:00 AM")

    def test_appointment_description_too_long(self): # Test appointment description length exception
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        with self.assertRaises(Exception): # Checks if exception is thrown from a long description
            Appointment("1", appointment_date, "Two cleaners will come to your business or home with all natural cleaning products and will wax your care also on the house")

    def test_appointment_description_null(self): # Test description null exception
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        with self.assertRaises(Exception): # Checks if exception is thrown from a null description
            Appointment("1", appointment_date, None)

    def test_appointmentID_not_empty(self): # Test appointment ID is not empty
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        with self.assertRaises(Exception): # Checks if exception is thrown from a missing ID
            Appointment("      ", appointment_date, "Two cleaners for 9:00 AM")

    def test_appointment_date_not_empty(self): # Test appointment date is not empty
        exception = False # Initializes variable to check for parse exception
        try:
            appointment_date = datetime.strptime("", '%m %d %Y %H %M')
        except ValueError:
            print("Incorrect format")
            exception = True; # Confirms exception

        self.assertTrue(exception); # Asserts exception occurred

    def test_appointment_description_not_empty(self): # Test description is not empty
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        with self.assertRaises(Exception): # Checks if exception is thrown from a missing description
            Appointment("1", appointment_date, "     ")

    def test_appointmentID_unique(self): # Tests if appointment ID is unique
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        appointment_list = []
        a_obj = Appointment("sameName", appointment_date, "Two cleaners for 9:00 AM") # Initializes Appointment object
        appointment_list.append(a_obj) # Appends object
        temp_appointment_ID = "sameName"
        with self.assertRaises(Exception): # Checks that exception is raised
            for i in range(len(appointment_list)):
                if appointment_list[i].appointment_ID == temp_appointment_ID: # Compares user input against existing IDs in the list
                    raise Exception("ID must be unique.")


