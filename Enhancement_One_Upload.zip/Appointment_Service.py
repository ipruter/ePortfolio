from Appointment import Appointment
from datetime import datetime

class Appointment_Service:

    def __init__(self, appointment_list): # Constructor
        self.appointment_list = appointment_list # Linked list

    def create(self, a_obj): # Creates a new object
        self.appointment_list.append(a_obj) # Appends a new object to the list
        return self.appointment_list

    def update(self, input_ID, input_date, input_description): # Updates an object
        for i in range(len(self.appointment_list)):
            if input_ID == self.appointment_list[i].appointment_ID: # Identifies the object the user wants to update
                self.appointment_list[i].appointment_date = input_date # Updates date
                self.appointment_list[i].appointment_description = input_description # Updates description
                return self.appointment_list

    def read(self, input_ID): # Reads object
        for i in range(len(self.appointment_list)):
            if input_ID == self.appointment_list[i].appointment_ID: # Identifies the object the user wants to read
                ID = self.appointment_list[i].appointment_ID
                date = str(self.appointment_list[i].appointment_date)
                description = self.appointment_list[i].appointment_description
                print(ID + ' ' + date + ' ' + description) # Displays the object's elements

    def delete(self, input_ID): # Deletes an object from the list
        for i in range(len(self.appointment_list)):
            if input_ID == self.appointment_list[i].appointment_ID: # Identifies the object the user wants to delete
                self.appointment_list.remove(self.appointment_list[i]) # Removes the object
                return self.appointment_list

    def read_all(self): # Displays the entire list
        for i in range(len(self.appointment_list)):
                ID = self.appointment_list[i].appointment_ID
                date = str(self.appointment_list[i].appointment_date)
                description = self.appointment_list[i].appointment_description
                print(ID + ' ' + date + ' ' + description)

if __name__ == "__main__": # The main method the project runs in
    appointment_list = []
    as_obj = Appointment_Service(appointment_list) # Creates list object
    select = input(str("c: Create\nr: Read\nu: Update\nd: Delete\na: Read all\ne: Exit")) # Displays menu and takes user input

    while select != "e": # Displays menu until the user exits
        if select == "c": # User selects create
            temp_appointment_ID = input(str("Enter a unique appointment ID: "))
            for i in range(len(as_obj.appointment_list)): # Checks for identical IDs
                if as_obj.appointment_list[i].appointment_ID == temp_appointment_ID: # Compares user input against existing IDs
                    raise Exception("ID must be unique.")

            i = input(str("Enter date, example: 12 25 2103 01 22"))
            try:
                temp_appointment_date = datetime.strptime(i, '%m %d %Y %H %M') # Converts string date to date type
            except ValueError:
                print("Incorrect format")
            temp_appointment_description = input(str("Enter appointment description: "))
            a_obj = Appointment(temp_appointment_ID, temp_appointment_date, temp_appointment_description) # Creates Appointment object
            as_obj.create(a_obj) # Calls the create method

        elif select == "r": # User selects read
            input_ID = input(str("Enter ID of the appointment you want to read"))
            as_obj.read(input_ID) # Calls read method

        elif select == "u": # User selects update
            input_ID = input(str("Enter ID of the appointment you want to update"))
            i = input(str("Enter date, example: 12 25 2103 01 22"))
            try:
                input_date = datetime.strptime(i, '%m %d %Y %H %M') # Converts string to date
            except ValueError:
                print("Incorrect format")
            input_description = input(str("Enter appointment description: "))
            as_obj.update(input_ID, input_date, input_description) # Calls update method

        elif select == "d": # User selects delete
            input_ID = input(str("Enter ID of the appointment you want to delete"))
            as_obj.delete(input_ID) # Calls delete method

        elif select == "a": # User selects read the entire list
            as_obj.read_all()

        else: # Handles any additional menu input
            print("Not an option")

        select = input(str("c: Create\nr: Read\nu: Update\nd: Delete\na: Read all\ne: Exit")) # Displays menu on loop
