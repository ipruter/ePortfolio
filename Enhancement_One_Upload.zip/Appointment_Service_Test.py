from Appointment_Service import Appointment_Service
from Appointment import Appointment
from datetime import datetime
from unittest import TestCase

class Appointment_Service_Test(TestCase):

    def test_create_appointment(self): # Tests create method
        appointment_list = []
        as_obj = Appointment_Service(appointment_list) # Initializes Appointment object
        temp_appointment_ID = "1"
        temp_appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        temp_appointment_description = "Two cleaners for 9:00 AM"
        test_appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        a_obj = Appointment(temp_appointment_ID, temp_appointment_date, temp_appointment_description) # Initializes Appointment_Service object
        as_obj.create(a_obj) # Creates appointment
        # Compares appended attributes to manual input attributes
        self.assertTrue(appointment_list[0].appointment_ID == "1")
        self.assertTrue(appointment_list[0].appointment_date == test_appointment_date)
        self.assertTrue(appointment_list[0].appointment_description == "Two cleaners for 9:00 AM")

    def test_update_appointment(self): # Tests update method
        appointment_list = []
        as_obj = Appointment_Service(appointment_list) # Initializes Appointment_Service object
        input_ID = "1"
        input_date = datetime.strptime("01 24 2155 11 21", '%m %d %Y %H %M')
        appointment_date2 = datetime.strptime("01 24 2155 11 21", '%m %d %Y %H %M')
        input_description = "One plumber for 11:00 AM"
        a_obj = Appointment("1", appointment_date2, "Two cleaners for 9:00 AM") # Initializes Appointment object
        as_obj.create(a_obj)
        as_obj.update(input_ID, input_date, input_description) # Updates appointment
        # Compares appended attributes to manual input attributes
        self.assertTrue(appointment_list[0].appointment_date == appointment_date2)
        self.assertTrue(appointment_list[0].appointment_description == "One plumber for 11:00 AM")

    def test_delete_appointment(self): # Tests delete method
        appointment_list = []
        as_obj = Appointment_Service(appointment_list) # Initializes Appointment_Service object
        appointment_ID = "2"
        appointment_date = datetime.strptime("12 25 2103 01 22", '%m %d %Y %H %M')
        a_obj = Appointment("1", appointment_date, "Two cleaners for 9:00 AM") # Initializes Appointment object
        as_obj.create(a_obj) # Creates appointment
        a_obj = Appointment("2", appointment_date, "Two cleaners for 9:00 AM") # Initializes Appointment object
        as_obj.create(a_obj) # Creates appointment
        as_obj.delete(appointment_ID) # Deletes appointment
        # Compares appended attributes to manual input attributes
        self.assertTrue(appointment_list[0].appointment_ID == "1")

