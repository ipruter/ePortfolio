package Database_Contact;
import java.sql.*;
import java.util.Scanner;
// Database class
public class Database {
	
	// Private variables
	private Connection connection = null;
	private Statement statement = null;
	
	// Constructor signs into database
	public Database() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); // Calls Java Database Connector driver
			this.connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb","root","password"); // Creates connection with database 
			this.statement = connection.createStatement(); // Converts connection into executable statement
		}catch(Exception e){ System.out.println(e);} 
	}
	
	// Creates a contact
	public void create(Contact contact_obj) {
		try {
			// SQL insert command
			String sql = "INSERT INTO testtable (id, first_name, last_name, phone, address) VALUES (?, ?, ?, ?, ?)";
			// Converts variables into strings in place of question marks
			PreparedStatement PrepStatement = connection.prepareStatement(sql);
			PrepStatement.setString(1, contact_obj.get_contact_ID());
			PrepStatement.setString(2, contact_obj.get_first_name());
			PrepStatement.setString(3, contact_obj.get_last_name());
			PrepStatement.setString(4, contact_obj.get_phone());
			PrepStatement.setString(5, contact_obj.get_address());
			PrepStatement.executeUpdate();
		}catch(Exception e){ System.out.println(e);} 	
	}
	
	// Finds a specific contact
	public void read(String name) {
		try {
			// Uses NLP to select a contact from their first and/or last name
			ResultSet result= statement.executeQuery("SELECT * FROM testtable WHERE (first_name) LIKE  '" + name + "%' OR (last_name) LIKE  '" + name + "%'");
			while(result.next())  { 
			System.out.println(result.getString(1)+"  "+result.getString(2)+"  "+result.getString(3)+"  "+result.getString(4)+"  "+result.getString(5));
			}
		}catch(Exception e){ System.out.println(e);} 
	}
	
	// Updates a contact
	public void update(String contact_ID, String first_name, String last_name, String phone, String address) {
		try {
			// SQL insert command
			String sql = "UPDATE testtable SET first_name=?, last_name=?, phone=?, address=? WHERE id=?";
			// Converts variables into strings in place of question marks
			PreparedStatement PrepStatement = connection.prepareStatement(sql);
		 	PrepStatement.setString(1, first_name);
			PrepStatement.setString(2, last_name);
			PrepStatement.setString(3, phone);
			PrepStatement.setString(4, address);
			PrepStatement.setString(5, contact_ID);
			PrepStatement.executeUpdate();
		}catch(Exception e){ System.out.println(e);} 
	}
	
	// Deletes a contact
	public void delete(String ID) {
		try {
			// SQL delete command
			String sql = "DELETE FROM testtable WHERE id=?";
			// Converts variables into strings in place of question marks
			PreparedStatement PrepStatement = connection.prepareStatement(sql);
			PrepStatement.setString(1, ID);
			PrepStatement.executeUpdate(); // Updates the database
		}catch(Exception e){ System.out.println(e);} 
	}
	
	// Displays all contacts
	public void read_all() {
		try {
			// SQL command reads all table content in ascending order by first name
			ResultSet result= statement.executeQuery("SELECT * FROM testtable ORDER BY first_name ASC;");  
			// Displays all content of each row
			while(result.next()) {
				System.out.println(result.getString(1)+"  "+result.getString(2)+"  "+result.getString(3)+"  "+result.getString(4)+"  "+result.getString(5));
			}
		}catch(Exception e){ System.out.println(e);} 
	}
	
	// Checks that the ID is unique
	public void unique_ID(String contact_ID){
		try {
			ResultSet result= statement.executeQuery("SELECT id FROM testtable"); // SQL statement selects ID from table
			// Checks each ID and throws exception if it already exists in the table
			while(result.next()) {
				if (contact_ID.equals(result.getString("id"))) {
					throw new IllegalArgumentException("Invalid ID.");
				}
			}
		}catch(Exception e){ System.out.println(e);} 
	}
	
	// Gets the private variable connection
	public Connection get_connection() {
		return connection;
	}
	
	// Gets the private variable statement
	public Statement get_statement() {
		return statement;
	}
	
	// Main method the program runs in
	public static void main(String[] args) {
		
		// Initializes variables
		Database database_obj = new Database();
		Scanner scan = new Scanner(System.in);
		String select = "";
		String newNum = "";
		String nameSearch = "";
		
		// Displays menu
		System.out.print("c: Create\nr: Read\nu: Update\nd: Delete\na: Read all\ne: Exit\n"); 
		select = scan.next();
		while (true) {
			// Checks if user wants to create a contact
			if (select.equals("c")) { 
				// Gets user input for each variable
				System.out.print("Enter contact's ID: ");
				String contact_ID = scan.next();
				database_obj.unique_ID(contact_ID);
				System.out.print("Enter contact's first name: ");
				String  first_name = scan.next(); 
		        System.out.print("Enter contact's last name: ");
		        String  last_name = scan.next();
		        System.out.print("Enter contact's phone number: ");
				String  phone = scan.next();
				System.out.print("Enter contact's address: ");
				String  address = scan.next();
				Contact contact_obj  = new Contact(contact_ID, first_name, last_name, phone, address); // Initializes contact object
				database_obj.create(contact_obj); // Calls create method
			}	
			// Checks if user wants to read a contact
			else if (select.equals("r")) {
				// Takes user input
				System.out.print("Enter contact's name: ");
				nameSearch = scan.next();
				database_obj.read(nameSearch); // Calls the read method
			}
			// Checks if user wants to update a contact
			else if (select.equals("u")) {
				// Gets user input for each variable
				System.out.print("Enter contact's ID: ");
				String contact_ID = scan.next();
				System.out.print("Enter contact's first name: ");
				String  first_name = scan.next(); 
		        System.out.print("Enter contact's last name: ");
		        String  last_name = scan.next();
		        System.out.print("Enter contact's phone number: ");
		        String  phone = scan.next();
				System.out.print("Enter contact's address: ");
				String  address = scan.next();
				database_obj.update(contact_ID, first_name, last_name, phone, address); // Calls update method
			}
			// Checks if user wants to delete a contact
			else if (select.equals("d")) {
				// Gets user input for each variable
				System.out.print("Enter the ID of the contact you want to delete: ");
				newNum = scan.next();
				database_obj.delete(newNum); // Calls delete method
			}
			// Checks if user wants to see all contacts
			else if (select.equals("a")) {
				database_obj.read_all(); // Calls read all method
			}
			// Checks if user wants to exit the menu
			else if (select.equals("e")) {
				break; // Exits loop
			}
			// Informs user they did not choose a valid option
			else {
				System.out.print("Not an option");
			}
			
			// Displays menu
			System.out.print("c: Create\nr: Read\nu: Update\nd: Delete\na: Read all\ne: Exit\n"); 
			select = scan.next();
		}
		// Closes database connection and scanners
		try{  
			database_obj.get_connection().close();  
			database_obj.get_statement().close();
		}catch(Exception e){ System.out.println(e);}  
		scan.close();
	}
}
