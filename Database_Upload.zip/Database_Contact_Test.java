package Database_Contact;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

// Contacts test class
class Database_Contact_Test {

	// Tests constructor
	@Test
	void test_contact() {
		Contact contact = new Contact("1", "Dave", "Davidson", "5555555555", "123 N St"); // Initializes objects
		assertTrue(contact.get_contact_ID().equals("1")); // Compares object ID with expected output
		assertTrue(contact.get_first_name().equals("Dave"));// Compares object name with expected output
		assertTrue(contact.get_last_name().equals("Davidson"));// Compares object name with expected output
		assertTrue(contact.get_phone().equals("5555555555"));// Compares object name with expected output
		assertTrue(contact.get_address().equals("123 N St")); // Compares object description with expected output
	}
		
	//Test contact ID null exception
	@Test
	void test_contact_ID_too_long() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("111111111111111111111111111111111", "Dave", "Davidson", "5555555555", "123 N St");});
	}
		
	//Test contact ID null exception
	@Test
	void test_contact_ID_null() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact(null, "Dave", "Davidson", "5555555555", "123 N St");});
	}
		
	//Test contact first name length exception
	@Test
	void test_first_name_too_long() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave11111111111111111111111111", "Davidson", "5555555555", "123 N St");});
	}
		
	//Test contact first name null exception
	@Test
	void test_contact_first_name_null() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", null, "Davidson", "5555555555", "123 N St");});
	}
		
	//Test contact first name length exception
	@Test
	void test_contact_last_name_too_long() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", "Davidson11111111111111111111111111", "5555555555", "123 N St");});
	}
		
	//Test contact last name null exception
	@Test
	void test_contact_last_name_null() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", null, "5555555555", "123 N St");});
	}
		
	//Test phone length exception
	@Test
	void test_contact_phone_too_long() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", "Davidson", "555555555555555555555555555", "123 N St");});
	}
				
	//Test phone null exception
	@Test
	void test_contact_phone_null() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", "Davidson", null, "123 N St");});
	}
				
	//Test address length exception
	@Test
	void test_contact_address_too_long() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", "Davidson", "5555555555", "12333333333333333333333333333 N St");});
	}
				
	//Test address null exception
	@Test
	void test_contact_address_null() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", "Davidson", "5555555555", null);});
	}
	
	//Test phone is not empty
	@Test
	void test_phone_not_empty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("      ", "Dave", "Davidson", "5555555555", "123 N St");});
	}
	
	//Test ID is not empty
	@Test
	void test_ID_not_empty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "       ", "Davidson", "5555555555", "123 N St");});
	}
	
	//Test first name is not empty
	@Test
	void test_first_name_not_empty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", "      ", "5555555555", "123 N St");});
	}
	
	//Test last name is not empty
	@Test
	void test_last_name_not_empty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", "Davidson", "     ", "123 N St");});
	}
	
	//Test address is not empty
	@Test
	void test_address_not_empty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Contact("1", "Dave", "Davidson", "5555555555", "     ");});
	}
	
	//Tests if contact ID is unique	
	@Test
	void testContactIDUnique() throws IllegalArgumentException {
		// Initializes objects
		Database tree_obj = new Database();
		Contact task_obj  = new Contact("test_ID", "Dave", "Davidson", "5555555555", "123 N St");
		tree_obj.create(task_obj); // Creates a contact
		tree_obj.create(task_obj); // Creates a contact	
		tree_obj.delete("test_ID"); // Deletes a contact	
	}
}
