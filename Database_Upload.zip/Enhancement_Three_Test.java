package Database_Contact;
import java.sql.*;
import static org.junit.jupiter.api.Assertions.*;
import java.sql.DriverManager;
import java.sql.ResultSet;
import org.junit.jupiter.api.Test;

// Database test class
class Database_Test {
	
	//Tests that the add function appends to the tree
	@Test
	void test_add_contact() {
		// Initializes objects
		Database database_obj = new Database();
		Contact contact_obj  = new Contact("test_ID", "Dave", "Davidson", "5555555555", "123 N St");
		database_obj.create(contact_obj); // Creates a task
		assertTrue(contact_obj.get_contact_ID().equals("test_ID")); // Compares object ID with expected output
		assertTrue(contact_obj.get_first_name().equals("Dave"));// Compares object name with expected output
		assertTrue(contact_obj.get_last_name().equals("Davidson"));// Compares object name with expected output
		assertTrue(contact_obj.get_phone().equals("5555555555"));// Compares object name with expected output
		assertTrue(contact_obj.get_address().equals("123 N St")); // Compares object description with expected output
		database_obj.delete("test_ID"); // Deletes contact
	}
		
	//Tests that the remove function deletes specified task
	@Test
	void test_remove_contact() {
		// Initializes objects
		Database database_obj = new Database();
		Contact contact_obj  = new Contact("test_ID", "Dave", "Davidson", "5555555555", "123 N St");
		database_obj.create(contact_obj); // Creates a contact
		Contact contact_obj2 = new Contact("test_ID2", "Dave", "Davidson", "5555555555", "123 N St");
		database_obj.create(contact_obj2); // Creates a contact
		database_obj.delete("test_ID2"); // Deletes contact
		assertTrue(contact_obj.get_contact_ID().equals("test_ID")); // Compares object ID with expected output
		database_obj.delete("test_ID"); // Deletes contact
	}	
		
	//Tests that the update function edits specified attributes
	@Test
	void test_update_contact() {
		// Initializes variables
		String contact_ID = "test_ID";
		String first_name = "new_value";
		String last_name = "new_value";
		String contact_phone = "2222222222";
		String contact_address = "new_value";
		Boolean contact_changed = false;
		// Initializes objects
		Database database_obj = new Database();
		Contact contact_obj  = new Contact("test_ID", "Dave", "Davidson", "5555555555", "123 N St");
		database_obj.create(contact_obj); // Creates a contact
		database_obj.update(contact_ID, first_name, last_name, contact_phone, contact_address); // Updates contact
		try {
			Class.forName("com.mysql.cj.jdbc.Driver"); // Calls Java Database Connector driver
			Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb","root","password"); // Creates connection with database 
			Statement statement = connection.createStatement(); // Converts connection into executable statement
			ResultSet result = statement.executeQuery("SELECT first_name FROM testtable"); // SQL statement to get the name from the table
			// Checks each row to find the new value in the database and mark it as found
			while(result.next())  
				if (result.getString(1).equals("new_value")) {
					contact_changed = true; 
				}
				assertTrue(contact_changed); // Checks that the new value was found in the database and asserts true
		}catch(Exception e){ System.out.println(e);};
		
		database_obj.delete("test_ID"); // Deletes contact
	}
}
