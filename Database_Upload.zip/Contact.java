package Database_Contact;

public class Contact {
	// Initializes private variables
	private String contact_ID;
	private String first_name;
	private String last_name;
	private String phone;
	private String address;
	
	// Constructor
	public Contact(String contact_ID, String first_name, String last_name, String phone, String address) { // Constructor for contact
		// Initializes temporary variables
		String temp_ID = contact_ID;
		String temp_first = first_name;
		String temp_last = last_name;
		String temp_phone = phone;
		String temp_address = address;
		
		if (contact_ID == null || contact_ID.length() > 10) { //Checks if contact ID value is null or is longer than ten characters
			throw new IllegalArgumentException("Invalid ID."); //Throws exceptions
		}
		
		if (first_name == null || first_name.length() > 10) {//Checks if first name is null or longer than ten characters
			throw new IllegalArgumentException("Invalid first name.");//Throws exceptions
		}
		
		if (last_name == null || last_name.length() > 10) {//Checks if last name is null or longer than ten characters
			throw new IllegalArgumentException("Invalid last name.");//Throws exceptions
		}
		
		if (phone == null || phone.length() != 10) {//Checks if phone number is null or not ten characters
			throw new IllegalArgumentException("Invalid phone number");//Throws exceptions
		}
		
		if (address == null || address.length() > 30) {//Checks if address is null or longer than thirty characters
			throw new IllegalArgumentException("Invalid address");//Throws exceptions
		}
		
		// Tests that ID is not empty
		temp_ID = contact_ID.replaceAll("\\s+","");
		if (temp_ID.equals("")) {
			throw new IllegalArgumentException("Field is required"); //Throws exceptions
		}
		
		// Tests that first name is not empty
		temp_first = first_name.replaceAll("\\s+","");
		if (temp_first.equals("")) {
			throw new IllegalArgumentException("Field is required"); //Throws exceptions
		}
		
		// Tests that last name is not empty
		temp_last = last_name.replaceAll("\\s+","");
		if (temp_last.equals("")) {
				throw new IllegalArgumentException("Field is required"); //Throws exceptions
		}
		
		// Tests that phone is not empty
		temp_phone = phone.replaceAll("\\s+","");
		if (temp_phone.equals("")) {
			throw new IllegalArgumentException("Field is required"); //Throws exceptions
		}
		
		// Tests that address is not empty
		temp_address = address.replaceAll("\\s+","");
		if (temp_address.equals("")) {
				throw new IllegalArgumentException("Field is required"); //Throws exceptions
		}
		
		// Adds attributes to new contact
		this.contact_ID = contact_ID;
		this.first_name = first_name;
		this.last_name = last_name;
		this.phone = phone;
		this.address = address;}
	
	public void set_task_ID(String task_ID){ //Sets ID
		this.contact_ID = task_ID;
	}
	
	public void set_first_name(String first_name){//Sets first name
		this.first_name = first_name;
	}
	
	public void set_last_name(String last_name){//Sets last name
		this.last_name = last_name;
	}
	
	public void set_phone(String phone){//Sets phone
		this.phone = phone;
	}
	
	public void set_address(String address){//Sets address
		this.address = address;
	}
	
	public String get_contact_ID(){//Gets ID
		return contact_ID;
	}
	
	public String get_first_name(){//Sets first name
		return first_name;
	}
	
	public String get_last_name(){//Sets last name
		return last_name;
	}
	
	public String get_phone(){//Sets phone
		return phone;
	}
	
	public String get_address(){//Sets address
		return address;
	}
}
