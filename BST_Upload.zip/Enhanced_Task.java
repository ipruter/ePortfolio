package Enhancement_Two;

// Task class
public class Enhanced_Task {
	// Initializes private variables
	private int task_ID;
	private String task_name;
	private String task_description;
	
	// Task constructor
	public Enhanced_Task(int task_ID, String task_name, String task_description) { // Constructor for contact
		String temp_task_name = task_name;
		String temp_task_description = task_description;
		
		if (task_ID == 0 || task_ID > 100000) { //Checks if task ID value is null or is longer than five characters
			throw new IllegalArgumentException("Invalid ID."); //Throws exceptions
		}
		
		if (task_name == null || task_name.length() > 10) {//Checks if task name is null or longer than ten characters
			throw new IllegalArgumentException("Invalid first name.");//Throws exceptions
		}
		
		if (task_description == null || task_description.length() > 30) {//Checks if task description is null or longer than thirty characters
			throw new IllegalArgumentException("Invalid address");//Throws exceptions
		}
		
		// Tests that task name is not empty
		temp_task_name = temp_task_name.replaceAll("\\s+","");
		if (temp_task_name.equals("")) {
			throw new IllegalArgumentException("Field is required"); //Throws exceptions
		}
		
		// Tests that task description is not empty
		temp_task_description = temp_task_description.replaceAll("\\s+","");
		if (temp_task_description.equals("")) {
				throw new IllegalArgumentException("Field is required"); //Throws exceptions
		}
		
		// Sets object's attribute values
		this.task_ID = task_ID;
		this.task_name = task_name;
		this.task_description = task_description;}
	
	// Sets task ID
	public void set_ID(int task_ID){
		this.task_ID = task_ID;
	}
	
	// Sets task name
	public void set_name(String task_name){
		this.task_name = task_name;
	}
	
	// Sets task description
	public void set_description(String task_description){
		this.task_description = task_description;
	}
	
	// Gets task ID
	public int get_ID(){
		return task_ID;
	}
	
	// Gets task name
	public String get_name(){
		return task_name;
	}
	
	// Gets task description
	public String get_description(){
		return task_description;
	}
	
	// Displays task object's attributes
	public String display_task() {
		    return task_ID + "," + task_name + "," + task_description;	
	}
}

