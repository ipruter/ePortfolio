package Enhancement_Two;
import java.util.Scanner;

// Class for the binary search tree
public class Binary_Search_Tree {
	// Class for the nodes in the tree
    public class Node { 
    	// Initializes node private variables
        private Enhanced_Task task; 
        private Node left, right;
        
        // Node constructor
        public Node(Enhanced_Task task_att){ 
            task = task_att; // Task object data
            left = right = null; // Pointers
        } 
        
        // Gets height of the tree
        int get_height() {
        	int left_height = 0; 
        	int right_height = 0;
        	
        	// Recursively calls get_height() in the left node if not null
        	if(this.left  != null) {
        		left_height = this.left.get_height();
        	}
        	
        	// Recursively calls get_height() in the right node if not null
        	if(this.right  != null) {
        		right_height = this.right.get_height();
        	}
        	// Adds one to the highest node in the tree every return
        	return 1 + Math.max(left_height,  right_height);
        }
        
        // Gets difference between the left and right trees and subtrees
        int height_difference(Node root) {
        	int height = 0;
        	// Handles null values on the right
        	if(this.right != null) {
        		height = root.right.get_height() - 0;
        	}
        	// Handles null values on the right
        	else if(this.left != null) {
        		height = 0 - root.left.get_height();
        	}
        	// Gets height when values arn't null
        	else {
        		height = root.right.get_height() - root.left.get_height();
        	}
        	return height;
        };   
    } 
    
    // Initializes tree private variable
    private Node root; 
    
    // Gets the root node
    Node get_root() {
    	return root;
    }
    
    // Constructor for the tree
    public Binary_Search_Tree(){ 
        root = null; 
    } 
    
    // Calls insert_node() in the main method
    public void create(Enhanced_Task task)  { 
        root = insert_node(root, task); 
    } 
   
    // Inserts a node into the tree
    public Node insert_node(Node root, Enhanced_Task task) { 
        // Returns root if tree is empty
        if (root == null) { 
            root = new Node(task); 
            return root; 
        } 
        
        // Ensures ID is unique
        if (task.get_ID() == root.task.get_ID()) {
        	throw new IllegalArgumentException("Invalid ID.");
        }
        // Inserts in the left subtree
        else if (task.get_ID() < root.task.get_ID()) {
            root.left = insert_node(root.left, task);
        }
        // Inserts in the left subtree
        else if (task.get_ID() > root.task.get_ID()) {
            root.right = insert_node(root.right, task); 
        }
        // Checks for tree balance and balances if necessary on every insert
        balance(root);
        
        return root;
    }
    
    // Calls find_node() in the main method
    public void read(int ID)  { 
    	Enhanced_Task task = null;
        root = find_node(root, task, ID); 
        // Displays object attributes if they exist
        if (root != null) {
        	System.out.print(root.task.get_ID() + " " + root.task.get_name() + " " + root.task.get_description() + "\n");
        }
        else {
        	System.out.print("Not in tree.");
        }
    } 
   
    // Traverses the tree to find a specific node
    public Node find_node(Node root, Enhanced_Task task, int task_ID)  { 
        // Checks if tree is empty or ID is found
        if (root == null || root.task.get_ID() == task_ID) {
            return root; 
        }
        
        // Traverses left subtree
        if (root.task.get_ID() > task_ID) {
            return find_node(root.left, task, task_ID); 
        }
        // Traverses right subtree
        return find_node(root.right, task, task_ID); 
    }
    
 // Calls update_node() in the main method
    public void update(int newInt, String task_name, String task_description) {
    	Enhanced_Task task = null;
        root = update_node(root, task, newInt, task_name, task_description); 
    } 
   
    // Updates node in tree
    public Node update_node(Node root, Enhanced_Task task, int task_ID, String task_name, String task_description)  { 
        // Checks if tree is empty
        if (root == null) {
        	return root; 
        }
        
        // Traverses left subtree
        if (task_ID < root.task.get_ID()) { 
            root.left = update_node(root.left, task, task_ID, task_name, task_description);
        }
        // Traverses right subtree
        else if (task_ID > root.task.get_ID()) {
            root.right = update_node(root.right, task, task_ID, task_name, task_description);
        }
        // Updates node when the IDs match
        else  { 
        	root.task.set_name(task_name);
        	root.task.set_description(task_description);
        } 
        return root; 
    } 
  
    // Calls remove_node() in the main method
    public void delete(int task_ID) {
    	Enhanced_Task task = null;
        root = remove_node(root, task, task_ID); 
    } 
   
    // Removes node from tree
    public Node remove_node(Node root, Enhanced_Task task, int task_ID)  { 
        //tree is empty
        if (root == null) {
        	return root; 
        }
       
        // Traverses left subtree
        if (task_ID < root.task.get_ID()) {
            root.left = remove_node(root.left, task, task_ID); 
        }
        // Traverses right subtree
        else if (task_ID > root.task.get_ID()) {
            root.right = remove_node(root.right, task, task_ID); 
        }
        else  { 
            // Sets parent's pointer to single right child
            if (root.left == null) {
                return root.right;
            }
            // Sets parent's pointer to single left child
            else if (root.right == null) {
                return root.left; 
            }
            // Sets nodes value to the minimum right subtrees value
            root.task.set_ID(min_value(root.right)); 
   
            // Replaces node with right child 
            root.right = remove_node(root.right, root.task, task_ID); 
        } 
        return root; 
    } 

    // Calls ordered_display() in the main method
    public void read_all() { 
    	ordered_display(root); 
    } 
   
    // Displays objects from least to greatest ID value 
    public void ordered_display(Node root) { 
        if (root != null) { 
        	ordered_display(root.left); // Finds left most node
            System.out.print(root.task.get_ID() + " " + root.task.get_name() + " " + root.task.get_description() + "\n"); // Displays left most node's object's attributes
            ordered_display(root.right); // Moves to the right
        } 
    }
    // Finds the minimum value
    public int min_value(Node root)  { 
    	int min = root.task.get_ID(); 
        // Iterates to the left most node
        while (root.left != null)  { 
            min = root.left.task.get_ID(); // Sets min to the left most ID
            root = root.left; // Set root to the left most node
        } 
        return min; 
    }
    
    // Rotates the tree to the left
    public Node left_rotation(Node root) {
        Node temp_right = null;
        temp_right = root.right;
        root.right = temp_right.left; // Sets nodes right node's left node to its right node
        temp_right.left = root; // Sets node to its right nodes left node
        temp_right.get_height(); // Gets new height
        return temp_right;
    }
    
    // Rotates the tree to the right
    public Node right_rotation(Node root) {
        Node temp_left = null;
        temp_left = root.left;
        root.left = temp_left.right; // Sets nodes left node's right node to its left node
        temp_left.right = root; // Sets node to its left nodes right node
        temp_left.get_height(); // Gets new height
        return temp_left;
    }
    
    // Rotates tree to the right then the left
    public Node right_left(Node root) {
        root.right = right_rotation(root); // Right rotation at node's right node
        root = left_rotation(root); // Left rotation at node
        root.get_height(); // Get new height
        return root;
    }
    
    // Rotates tree to the left then the right
    public Node left_right(Node root){
    	root.left = left_rotation(root); // Left rotation at node's left node
        root = right_rotation(root); // Right rotation at node 
        root.get_height(); // Get new height
        return root;
    }
    
    // Balances the tree
    public Node balance (Node root) {
    	// Rotates right if imbalance is on the left on child and grand child
        if(root.height_difference(root) < -1 && root.left.height_difference(root) == -1) {
        	return right_rotation(root);
        }
        // Rotates left if imbalance is on the right on child and grand child
        else if(root.height_difference(root) > 1 && root.right.height_difference(root) == 1){
        	return left_rotation(root);
        }
        // Rotates left, then right if imbalance is on the left child and right grand child
        else if(root.height_difference(root) < -1 && root.left.height_difference(root) == 1) {
        	return left_right(root);
        }
        // Rotates right, then left if imbalance is on the right child and left grand child
        else if(root.height_difference(root) > 1 && root.right.height_difference(root) == -1) {
        	return right_left(root);
        }
        return root;
    }
    
    // Main method
    public static void main(String[] args) {
		//Initializes objects and variables
		Binary_Search_Tree tree_obj = new Binary_Search_Tree();
		Scanner scan = new Scanner(System.in);
		String select = "";
		int ID = 0;
	
		// Displays menu
		System.out.print("c: Create\nr: Read\nu: Update\nd: Delete\na: Read all\ne: Exit\n"); 
		select = scan.next();
	
		// Loops until exit is selected
		while (select != "e") {
		 	// Checks if user selected create
		 	if (select.equals("c")) { 
			 	// User enters the task ID
			 	System.out.print("Enter task's task ID: ");
			 	int task_ID = scan.nextInt();
			 	// User enters the task name
			 	System.out.print("Enter task name: ");
			 	String  task_name = scan.next();
			 	// User enters the task description
			 	System.out.print("Enter task description: ");
			 	String  task_description = scan.next();
			 	// Creates new task object
			 	Enhanced_Task task_obj  = new Enhanced_Task(task_ID, task_name, task_description);
	         	// Calls create() method
			 	tree_obj.create(task_obj);	 
		 	}
		 	// Checks if user selected read
		 	else if (select.equals("r")) {
		 	    // User enters the task ID
			 	System.out.print("Enter task ID you're looking for: ");
			 	ID = scan.nextInt();
			 	// Calls read() method
			 	tree_obj.read(ID);
			 	}
		 	// Checks if user selected update
		 	else if (select.equals("u")) {
		 		// User enters the task ID
			 	System.out.print("Enter task's ID you would like to update: ");
			 	ID = scan.nextInt();
			 	// User enters the task name
			 	System.out.print("Enter task name: ");
			 	String  task_name = scan.next();
			 	// User enters the task description
			 	System.out.print("Enter task description: ");
			 	String  task_description = scan.next();
			 	// Calls update() method
			 	tree_obj.update(ID, task_name, task_description);
			 	}
		 	// Checks if user selected delete
		 	else if (select.equals("d")) {
		 		// User enters the task ID
			 	System.out.print("Enter task's ID you would like to delete: ");
			 	ID = scan.nextInt();
			 	// Calls delete() method
			 	tree_obj.delete(ID);
		 	}
		 	// Checks if user selected read all
		 	else if (select.equals("a")) {
			 	// Calls read_all() method
			 	tree_obj.read_all();
		 	}
		 	// Checks if user selected exit
		 	else if (select.equals("e")) {
			 	break;
		 	}
		 	// Informs user they did not make a valid selection
		 	else {
			 	System.out.print("Not an options.");
		 	}
		 	// Displays menu
		 	System.out.print("\nc: Create\nr: Read\nu: Update\nd: Delete\na: Read all\ne: Exit\n"); 
		 	//scan.nextLine();
		 	select = scan.next();
		}
		scan.close();
	}
}
