package Enhancement_Two;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class Binary_Search_Tree_Test {
	// Tests that the add function appends to the tree
	@Test
	void test_add_task() {
		// Initializes objects
		Binary_Search_Tree tree_obj = new Binary_Search_Tree();
		Enhanced_Task task_obj  = new Enhanced_Task(1, "Cleaning", "Clean your busines or home");
		tree_obj.create(task_obj); // Creates a task
		assertTrue(tree_obj.get_root() != null); // Tests if the task was appended to the tree
	}
	
	// Tests that the remove function deletes specified task
	@Test
	void test_remove_task() {
		// Initializes objects
		Binary_Search_Tree tree_obj = new Binary_Search_Tree();
		Enhanced_Task task_obj  = new Enhanced_Task(1, "Cleaning","Clean your busines or home"); 
		tree_obj.create(task_obj); // Creates a task
		tree_obj.delete(1); // Deletes task
		assertTrue(tree_obj.get_root() == null); // Checks that the tree is empty
	}	
	
	// Tests that the update function edits specified attributes
	@Test
	void test_update_task() {
		// Initializes objects
		Binary_Search_Tree tree_obj = new Binary_Search_Tree();
		Enhanced_Task task_obj  = new Enhanced_Task(1, "Cleaning", "Clean your busines or home");
		tree_obj.create(task_obj); // Creates task
		tree_obj.update(1, "TheNewValue", "TheNewValue"); // Updates task
		assertTrue(task_obj.get_ID() == 1); // Compares ID to expected output
		assertTrue(task_obj.get_name().equals("TheNewValue")); // Compares name to expected output
		assertTrue(task_obj.get_description().equals("TheNewValue")); // Compares description to expected output
	}
}
