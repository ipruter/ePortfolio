package Enhancement_Two;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

// Task test class
class Enhanced_Task_Test {
	// Tests constructor
	@Test
	void test_task() {
		// Creates task object
		Enhanced_Task task = new Enhanced_Task(1, "Cleaning", "Clean your business or home");
		assertTrue(task.get_ID() == 1); // Compares object ID with expected output
		assertTrue(task.get_name().equals("Cleaning"));// Compares object name with expected output
		assertTrue(task.get_description().equals("Clean your business or home")); // Compares object description with expected output
	}
	
	//Test task ID null exception
	@Test
	void test_task_ID_null() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Enhanced_Task(0, "Cleaning", "Clean your business or home");});
	}
	
	//Test task name length exception
	@Test
	void test_task_name_too_long() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Enhanced_Task(1, "Cleaning service for those who value a really clean home or business", "Clean your business or home");});
	}
	
	//Test task name null exception
	@Test
	void test_task_name_null() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Enhanced_Task(1, null, "Clean your business or home");});
	}
	
	//Test description length exception
	@Test
	void test_task_description_too_long() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Enhanced_Task(1, "Cleaning", "Clean your business or home with all natural cleaning products which also comes with a complimentary, premium car waxing");});
	}
	
	//Test description null exception
	@Test
	void test_task_description_null() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Enhanced_Task(1, "Cleaning", null);});
	}
	
	//Test task name is not empty
	@Test
	void test_task_name_not_empty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Enhanced_Task(1, "    ", "Clean your business or home");});
	}
	
	//Test description is not empty
	@Test
	void test_task_description_not_empty() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {new Enhanced_Task(1, "Cleaning", "     ");});
	}
}
